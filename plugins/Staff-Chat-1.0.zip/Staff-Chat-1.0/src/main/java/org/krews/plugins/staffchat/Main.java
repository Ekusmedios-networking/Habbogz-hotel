// 
// Decompiled by Procyon v0.5.36
// 

package org.krews.plugins.staffchat;

import com.eu.habbo.plugin.EventHandler;
import com.eu.habbo.habbohotel.messenger.MessengerBuddy;
import com.eu.habbo.plugin.events.users.UserLoginEvent;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.Emulator;
import com.eu.habbo.plugin.EventListener;
import com.eu.habbo.plugin.HabboPlugin;

public class Main extends HabboPlugin implements EventListener
{
    public void onEnable() {
        Emulator.getPluginManager().registerEvents((HabboPlugin)this, (EventListener)this);
    }
    
    public void onDisable() throws Exception {
    }
    
    public boolean hasPermission(final Habbo habbo, final String s) {
        return false;
    }
    
    @EventHandler
    public static void onUserLoginEvent(final UserLoginEvent event) throws Exception {
        if (event.habbo.hasPermission("acc_staff_chat")) {
            final StaffChatBuddy buddy = new StaffChatBuddy(-1, "Staff Chat", "", (short)0, event.habbo.getHabboInfo().getId());
            buddy.setLook("ADM");
            buddy.setOnline(true);
            event.habbo.getMessenger().addBuddy((MessengerBuddy)buddy);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package org.krews.plugins.staffchat;

import com.eu.habbo.habbohotel.users.HabboGender;
import com.eu.habbo.messages.ServerMessage;
import com.eu.habbo.messages.outgoing.friends.FriendChatMessageComposer;
import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.messenger.Message;
import com.eu.habbo.habbohotel.commands.CommandHandler;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.habbohotel.messenger.MessengerBuddy;

public class StaffChatBuddy extends MessengerBuddy
{
    public StaffChatBuddy(final int id, final String username, final String look, final Short relation, final int userOne) {
        super(id, username, look, relation, userOne);
    }
    
    public void run() {
    }
    
    public void onMessageReceived(final Habbo from, final String message) {
        if (message.startsWith(":")) {
            CommandHandler.handleCommand(from.getClient(), message);
            return;
        }
        final Message chatMessage = new Message(from.getHabboInfo().getId(), this.getId(), message);
        Emulator.getGameServer().getGameClientManager().sendBroadcastResponse(new FriendChatMessageComposer(chatMessage, this.getId(), from.getHabboInfo().getId()).compose(), "acc_staff_chat", from.getClient());
    }
    
    public void serialize(final ServerMessage message) {
        message.appendInt(Integer.valueOf(this.getId()));
        message.appendString(this.getUsername());
        message.appendInt(Integer.valueOf((int)(this.getGender().equals((Object)HabboGender.M) ? 0 : 1)));
        message.appendBoolean(Boolean.valueOf(true));
        message.appendBoolean(Boolean.valueOf(false));
        message.appendString(this.getLook());
        message.appendInt(Integer.valueOf(0));
        message.appendString("");
        message.appendString("");
        message.appendString("");
        message.appendBoolean(Boolean.valueOf(true));
        message.appendBoolean(Boolean.valueOf(false));
        message.appendBoolean(Boolean.valueOf(false));
        message.appendShort(0);
    }
}
